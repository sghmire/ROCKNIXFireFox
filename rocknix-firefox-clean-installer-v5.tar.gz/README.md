# Firefox for ROCKNIX (ARM64)

This is an early proof-of-concept installer for Mozilla's official Linux ARM64
Firefox build on ROCKNIX. It installs entirely below `/storage`, so it does not
modify ROCKNIX's immutable system partition.

The consolidated installer currently includes ROCKNIX integration v5.

## What this first milestone does

- Downloads Mozilla's current official Linux ARM64 Firefox archive.
- Installs it atomically under `/storage/apps/firefox-rocknix`.
- Preserves the previous installation as `firefox.previous` during an update.
- Creates a launcher at `/storage/roms/ports/Firefox.sh`.
- Loads a Firefox-specific InputPlumber mouse/keyboard profile while the browser
  is running, then restores the normal gamepad profile when Firefox exits.
- Writes a dependency and display diagnostic report to
  `/storage/apps/firefox-rocknix/diagnostics.txt`.

The first run may not launch yet. That is expected if the current ROCKNIX image
does not contain GTK3 or another desktop library. The diagnostic report tells us
exactly what must go in the bundled runtime without replacing ROCKNIX's glibc,
graphics drivers, or kernel-facing libraries.

## Install directly on the Flip 2

Transfer this directory to the device (for example, into `/storage/downloads`),
SSH into ROCKNIX, and run:

```sh
cd /storage/downloads/rocknix-firefox
chmod +x install.sh launch.sh diagnose.sh install-controls.sh
./install.sh
```

When installation finishes, run the launch test:

```sh
/storage/apps/firefox-rocknix/launch.sh
```

If Firefox does not open, show the report:

```sh
cat /storage/apps/firefox-rocknix/diagnostics.txt
```

Paste the complete report back into the Codex conversation if launch fails.
Current SM8250 nightly images already contain the required GTK runtime.

## Clean reinstall

`reset-firefox.sh` removes the installed Firefox application and Ports launcher,
restores the normal input services, and deliberately preserves bookmarks,
history, cookies, and settings in `/storage/.mozilla/firefox-rocknix`.

```sh
./reset-firefox.sh
./install.sh
```

For a complete factory reset, remove `/storage/.mozilla/firefox-rocknix` only
after separately backing up anything important.

## Controller layout

| Control | Browser action |
|---|---|
| Right stick | Mouse pointer |
| A / R2 | Left click |
| L2 | Right click |
| B | Escape / close menu |
| X | Reload |
| Y | Show/hide onscreen keyboard |
| D-pad | Arrow keys |
| L1 / R1 | Scroll up / down |
| Left stick up / down | Page up / down |
| Start | Enter |
| Select | Tab |
| L1 + Select + Start | Standard ROCKNIX exit chord |

The onscreen keyboard is intentionally manual because `wvkbd` does not receive
reliable text-field focus notifications from Firefox. Tap or select a text
field, then press Y to show it; press Y again to hide it.

Firefox runs as the only tiled window on a dedicated Sway workspace rather than
as a true fullscreen container. This looks full-screen while allowing wvkbd's
Wayland layer to reserve space and remain visible.

After a successful launch, refresh the EmulationStation game list and open
`Ports > Firefox`.

## Optional deployment from macOS or Linux

If SSH is enabled on ROCKNIX and the device is reachable on the network:

```sh
./deploy.sh <device-ip-or-hostname>
```

The script copies this kit to the device and runs the installer over SSH. It
uses the `root` account; ROCKNIX's default password is `rocknix` unless it was
changed in System Settings.

## Files and persistent data

| Purpose | Device path |
|---|---|
| Application | `/storage/apps/firefox-rocknix/firefox` |
| Future bundled libraries | `/storage/apps/firefox-rocknix/runtime/lib` |
| Firefox profile | `/storage/.mozilla/firefox-rocknix` |
| Logs | `/storage/apps/firefox-rocknix/logs` |
| Ports launcher | `/storage/roms/ports/Firefox.sh` |

## Safety notes

- The launcher does not disable Firefox's process sandbox.
- The installer never installs or bundles glibc. Firefox and bundled libraries
  must use the version supplied by ROCKNIX.
- A failed download or extraction does not replace the working installation.
- The official download URL follows Mozilla's latest stable ARM64 release.
